#!/bin/zsh
set -e
trap 'status=$?; echo ""; echo "脚本失败，退出码：$status"; echo "请把这个窗口里的信息发给开发者。"; echo ""; read -r "?按回车关闭窗口..."; exit $status' ERR

PLUGIN_ID="com.makienn.photoshop.color-layer-batch-merge"
PLUGIN_VERSION="0.3.0"
DEST_DIR="/Library/Application Support/Adobe/UXP/extensions/$PLUGIN_ID-$PLUGIN_VERSION"

echo ""
echo "Removing system-level install:"
echo "$DEST_DIR"
echo ""
echo "接下来会请求管理员密码。"
echo ""

if [ -d "$DEST_DIR" ]; then
  sudo rm -rf "$DEST_DIR"
fi

echo "已移除系统级安装。"
echo ""
read -r "?按回车关闭窗口..."
