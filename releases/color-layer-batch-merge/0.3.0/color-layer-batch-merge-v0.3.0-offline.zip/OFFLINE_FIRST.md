# 离线优先发布原则

本项目的核心发布策略是 offline-first。

## 原因

Creative Cloud Desktop、CCX 安装器和 Adobe UXP Developer Tool 都可能受到登录态、邮箱验证、授权缓存、网络连接和地区网络环境影响。普通用户不应该为了安装一个小工具，被迫排查 Adobe 账号状态。

## 项目规则

1. 离线 zip 是主交付物，必须内含同版本 CCX。
2. CCX 和完整源文件必须同时交付。
3. 普通用户安装路径必须尽量不依赖 UXP Developer Tool。
4. 离线包必须包含中文说明、txt 说明、安装脚本、卸载脚本和安装检查脚本。
5. 如果 UXP 直接离线安装被 Photoshop 阻断，必须把失败结果记录为项目事实，并评估替代技术路线。

## 当前安装路线

- 推荐入口：INSTALL_CCX.command 或直接双击包内 CCX
- 用户级 UXP 诊断脚本：INSTALL_LOCAL.command（已知不显示）
- 系统级 UXP 诊断脚本：INSTALL_SYSTEM.command（已知不显示）
- 安装检查脚本：CHECK_INSTALL.command
- 卸载脚本：UNINSTALL_LOCAL.command / UNINSTALL_SYSTEM.command
- 下一步推荐路线：CEP 离线版本

## 离线定义

离线包必须把安装所需文件全部放在本地，不下载远程运行资源。Adobe Creative Cloud Desktop 可以作为本机安装入口，但插件运行不能依赖登录或联网。
