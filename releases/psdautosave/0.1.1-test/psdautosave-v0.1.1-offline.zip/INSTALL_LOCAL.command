#!/bin/zsh
set -e
trap 'status=$?; echo ""; echo "脚本失败，退出码：$status"; echo "请把这个窗口里的信息发给开发者。"; echo ""; read -r "?按回车关闭窗口..."; exit $status' ERR

PLUGIN_ID="com.makienn.photoshop.psdautosave"
PLUGIN_NAME="psdautosave"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_DIR="$SCRIPT_DIR/psdautosave"
DEST_BASE="$HOME/Library/Application Support/Adobe/UXP/extensions"
DEST_DIR="$DEST_BASE/$PLUGIN_ID"
STAMP="$(date +%Y%m%d-%H%M%S)"

echo ""
echo "Installing $PLUGIN_NAME"
echo "Source: $SRC_DIR"
echo "Target: $DEST_DIR"
echo ""

if [ ! -f "$SRC_DIR/manifest.json" ]; then
  echo "ERROR: 找不到插件 manifest.json。请确认这个脚本和 psdautosave 文件夹在同一个解压目录里。"
  read -r "?按回车退出..."
  exit 1
fi

mkdir -p "$DEST_BASE"

if [ -d "$DEST_DIR" ]; then
  BACKUP_DIR="$DEST_DIR.backup-$STAMP"
  echo "发现已有安装，先备份到："
  echo "$BACKUP_DIR"
  mv "$DEST_DIR" "$BACKUP_DIR"
fi

/usr/bin/ditto "$SRC_DIR" "$DEST_DIR"

echo ""
echo "安装完成。"
echo "请重新打开 Photoshop，然后在 Plugins 菜单里查找 $PLUGIN_NAME。"
echo ""
echo "如果没有出现，说明 Photoshop 当前版本可能不扫描用户级 UXP extensions 目录。"
echo "这时可以把这个结果告诉开发者，再尝试 UXP Developer Tool 或真实 CCX 路径。"
echo ""
read -r "?按回车关闭窗口..."
