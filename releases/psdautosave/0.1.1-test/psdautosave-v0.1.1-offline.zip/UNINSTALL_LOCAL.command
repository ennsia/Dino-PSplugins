#!/bin/zsh
set -e
trap 'status=$?; echo ""; echo "脚本失败，退出码：$status"; echo "请把这个窗口里的信息发给开发者。"; echo ""; read -r "?按回车关闭窗口..."; exit $status' ERR

PLUGIN_ID="com.makienn.photoshop.psdautosave"
DEST_DIR="$HOME/Library/Application Support/Adobe/UXP/extensions/$PLUGIN_ID"

echo ""
echo "Removing user-level install:"
echo "$DEST_DIR"
echo ""

if [ -d "$DEST_DIR" ]; then
  rm -rf "$DEST_DIR"
  echo "已移除用户级安装。"
else
  echo "没有找到用户级安装目录。"
fi

echo ""
read -r "?按回车关闭窗口..."
