#!/bin/zsh
set -e
trap 'status=$?; echo ""; echo "启动安装失败，退出码：$status"; echo "也可以直接双击同目录中的 CCX 文件。"; echo ""; read -r "?按回车关闭窗口..."; exit $status' ERR

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CCX_PATH="$SCRIPT_DIR/Dino-psdautosave_PS.ccx"
CC_APP="/Applications/Utilities/Adobe Creative Cloud/ACC/Creative Cloud.app"

echo ""
echo "准备安装 psdautosave 0.1.1"
echo "$CCX_PATH"
echo ""

if [ ! -f "$CCX_PATH" ]; then
  echo "ERROR: 找不到 CCX 文件，请完整解压离线包后再运行。"
  read -r "?按回车关闭窗口..."
  exit 1
fi

if [ -d "$CC_APP" ]; then
  open -g "$CC_APP"
  sleep 3
fi

open "$CCX_PATH"

echo "已交给 Adobe 插件安装器。请在弹出的窗口中确认安装。"
echo "安装完成后退出并重新打开 Photoshop。"
echo ""
read -r "?按回车关闭窗口..."
