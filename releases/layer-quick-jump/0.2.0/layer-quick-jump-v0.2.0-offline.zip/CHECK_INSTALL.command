#!/bin/zsh
set -e

PLUGIN_ID="com.makienn.photoshop.layer-quick-jump"
PLUGIN_VERSION="0.2.0"
USER_DIR="$HOME/Library/Application Support/Adobe/UXP/extensions/$PLUGIN_ID"
SYSTEM_DIR="/Library/Application Support/Adobe/UXP/extensions/$PLUGIN_ID-$PLUGIN_VERSION"

echo ""
echo "检查 Layer Quick Jump 安装状态"
echo ""

echo "用户级目录："
echo "$USER_DIR"
if [ -d "$USER_DIR" ]; then
  echo "存在"
  ls -la "$USER_DIR"
else
  echo "不存在"
fi

echo ""
echo "系统级目录："
echo "$SYSTEM_DIR"
if [ -d "$SYSTEM_DIR" ]; then
  echo "存在"
  ls -la "$SYSTEM_DIR"
else
  echo "不存在"
fi

echo ""
read -r "?按回车关闭窗口..."
