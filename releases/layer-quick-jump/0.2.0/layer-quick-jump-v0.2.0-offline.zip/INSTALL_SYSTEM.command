#!/bin/zsh
set -e
trap 'status=$?; echo ""; echo "脚本失败，退出码：$status"; echo "请把这个窗口里的信息发给开发者。"; echo ""; read -r "?按回车关闭窗口..."; exit $status' ERR

PLUGIN_ID="com.makienn.photoshop.layer-quick-jump"
PLUGIN_VERSION="0.2.0"
PLUGIN_NAME="Layer Quick Jump"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_DIR="$SCRIPT_DIR/layer-quick-jump"
DEST_BASE="/Library/Application Support/Adobe/UXP/extensions"
DEST_DIR="$DEST_BASE/$PLUGIN_ID-$PLUGIN_VERSION"
STAMP="$(date +%Y%m%d-%H%M%S)"

echo ""
echo "Installing $PLUGIN_NAME to system-level Adobe UXP extensions"
echo "Source: $SRC_DIR"
echo "Target: $DEST_DIR"
echo ""
echo "接下来会请求管理员密码，用来写入 /Library/Application Support/Adobe/UXP/extensions。"
echo "输入密码时 Terminal 不会显示星号，这是 macOS 的正常行为。"
echo ""

if [ ! -f "$SRC_DIR/manifest.json" ]; then
  echo "ERROR: 找不到插件 manifest.json。请确认这个脚本和 layer-quick-jump 文件夹在同一个解压目录里。"
  read -r "?按回车退出..."
  exit 1
fi

sudo mkdir -p "$DEST_BASE"

if [ -d "$DEST_DIR" ]; then
  BACKUP_DIR="$DEST_DIR.backup-$STAMP"
  echo "发现已有系统级安装，先备份到："
  echo "$BACKUP_DIR"
  sudo mv "$DEST_DIR" "$BACKUP_DIR"
fi

sudo /usr/bin/ditto "$SRC_DIR" "$DEST_DIR"

if command -v xattr >/dev/null 2>&1; then
  sudo xattr -dr com.apple.quarantine "$DEST_DIR" >/dev/null 2>&1 || true
fi

echo ""
echo "系统级安装完成。"
echo "请重新打开 Photoshop，然后在 Plugins 菜单里查找 $PLUGIN_NAME。"
echo ""
echo "如果仍然没有出现，说明 Photoshop 当前版本可能不接受直接复制的第三方 UXP 插件。"
echo ""
read -r "?按回车关闭窗口..."
