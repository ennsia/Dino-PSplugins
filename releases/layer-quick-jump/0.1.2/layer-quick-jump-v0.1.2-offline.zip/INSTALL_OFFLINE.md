# Layer Quick Jump 离线安装说明

这个压缩包是本项目的完整离线交付包，已经包含同版本 CCX、插件源文件、中文说明和诊断脚本。插件运行时不需要联网。

## 推荐方式 A：安装包内 CCX

1. 退出 Photoshop。
2. 双击 INSTALL_CCX.command；也可以直接双击 Eisen-layer-quick-jump_PS.ccx。
3. 按 Adobe 安装窗口提示完成安装。
4. 重新打开 Photoshop。
5. 在“增效工具 / Plugins”菜单中打开 Layer Quick Jump。

CCX 文件和插件功能均已完整放在本地。Creative Cloud Desktop 只负责调用 Adobe 的本机插件安装服务；插件运行不需要网络资源。

## 备用方式 B：UXP Developer Tool 加载

1. 打开 Adobe UXP Developer Tool。
2. 点击 Add Plugin，选择解压后的 layer-quick-jump 文件夹。
3. 点击 Load。
4. 在 Photoshop 的 Plugins 菜单中打开插件。

## 已知无效的诊断方式

- INSTALL_LOCAL.command 和 INSTALL_SYSTEM.command 仅供诊断。
- 2026-06-15 在 Photoshop 2025 上实测，直接复制 UXP 文件夹不会让插件出现在菜单中。
- 不建议普通用户使用这两条裸目录复制路线。

## 兼容性

- 目标版本：Photoshop 25.0.0 或更新版本。
- 2026-06-19 已确认 CCX 可被 Adobe UPI 安装并注册到 Photoshop 2025。
- 安装或升级后需要重启 Photoshop。
